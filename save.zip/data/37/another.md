This is a simple paragraph with normal text.

This paragraph has    multiple    spaces that should be preserved.

### bold
This text should be bold.
### unbold

### link Summary Example
This should create a link to "Summary Example"

### table
Name | Role | Department
John Doe | Developer | Engineering
Jane Smith | Designer | UX
Mark Johnson | Manager | Operations
### endtable

This is more normal text after the table.

### bold
Here's another bold section with
multiple lines
### unbold